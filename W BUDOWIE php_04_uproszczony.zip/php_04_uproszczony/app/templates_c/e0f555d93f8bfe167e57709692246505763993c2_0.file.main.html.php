<?php
/* Smarty version 4.3.2, created on 2023-11-17 11:04:53
  from 'C:\xampp\htdocs\php_04_uproszczony\templates\main.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.2',
  'unifunc' => 'content_65573ac537ea67_28220988',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e0f555d93f8bfe167e57709692246505763993c2' => 
    array (
      0 => 'C:\\xampp\\htdocs\\php_04_uproszczony\\templates\\main.html',
      1 => 1700215492,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_65573ac537ea67_28220988 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
?>
<!doctype html>
<html lang="pl">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="<?php echo (($tmp = $_smarty_tpl->tpl_vars['page_description']->value ?? null)===null||$tmp==='' ? 'Opis domyślny' ?? null : $tmp);?>
">
	<title><?php echo (($tmp = $_smarty_tpl->tpl_vars['page_title']->value ?? null)===null||$tmp==='' ? "Tytuł domyślny" ?? null : $tmp);?>
</title>
	<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['app_url']->value;?>
/css/style.css">	
    <?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['app_url']->value;?>
/js/jquery-1.12.4.min.js"><?php echo '</script'; ?>
>
    <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['app_url']->value;?>
/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['app_url']->value;?>
/css/style.css">
    <?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['app_url']->value;?>
/js/bootstrap.js"><?php echo '</script'; ?>
>
</head>
<body>

<div class="header">
	<nav class="navbar navbar-inverse navbar-fixed-top" style="margin-bottom: 0;">

		<div class="container-fluid">

			<div class="navbar-header">

				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
					<span class="sr-only"></span>
					<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				</button>

				<a class="navbar-brand">Kalkulator Kredytowy | KB</a>

			</div>

			<div id="navbar" class="navbar-collapse collapse" aria-expanded="false" style="height: 1px;">

				<ul class="nav navbar-nav navbar-right">

					<?php if (((isset($_smarty_tpl->tpl_vars['chroniona']->value)))) {?>
						<li><a href="<?php echo $_smarty_tpl->tpl_vars['app_url']->value;?>
/app/calc.php"><span class="glyphicon glyphicon-ok-circle"></span> Powrót do kalkulatora</a></li>
					<?php }?>
					<li><a href="#app_content"><span class="glyphicon glyphicon-ok-circle"></span> Idź do formularza</a></li>
					<li><a href="#app_top"><span class="glyphicon glyphicon-ok-circle"></span> Idź do góry strony</a></li>


				</ul>

			</div>

		</div>

	</nav>
	<div class="splash-container" style="width:90%; margin: 2em auto; background-color: white; padding: 20px; margin-top: 40px;">
            
		<div class="splash">
			<h1 class="splash-head"><img src="<?php echo $_smarty_tpl->tpl_vars['app_url']->value;?>
/img/logo.jpg" style="width:30px; height: 30px;"> <?php echo (($tmp = $_smarty_tpl->tpl_vars['page_header']->value ?? null)===null||$tmp==='' ? "Tytuł domyślny" ?? null : $tmp);?>
</h1>
			<p class="splash-subhead">
				<?php echo (($tmp = $_smarty_tpl->tpl_vars['page_description']->value ?? null)===null||$tmp==='' ? "Opis domyślny" ?? null : $tmp);?>

			</p>
		</div>
		
	</div>

</div>

<div class="content">
	<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_77315951365573ac537d829_16105473', 'content');
?>

</div>

<div class="footer" style="width:90%; margin: 2em auto; background-color: white; padding: 20px;">
	<p>
	<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_102311351565573ac537e231_29599694', 'footer');
?>

	</p>
</div>

</body>
</html><?php }
/* {block 'content'} */
class Block_77315951365573ac537d829_16105473 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_77315951365573ac537d829_16105473',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
 Domyślna treść zawartości .... <?php
}
}
/* {/block 'content'} */
/* {block 'footer'} */
class Block_102311351565573ac537e231_29599694 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'footer' => 
  array (
    0 => 'Block_102311351565573ac537e231_29599694',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
 Domyślna treść stopki .... <?php
}
}
/* {/block 'footer'} */
}
